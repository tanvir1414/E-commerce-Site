﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Products : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ConnectionString);
    //conn.Open();
    string a, b;
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }

    protected void Button1_Click1(object sender, EventArgs e)
    {
        a = Class1.GetRandomPassword(10).ToString();
        f1.SaveAs(Request.PhysicalApplicationPath + "./images/" + a + f1.FileName.ToString());

        b = "images/" + a + f1.FileName.ToString();
        conn.Open();

        string productQuery = "INSERT INTO Product(ProductId,ProductName,ProductPrice,ProductQuantity,ProductImage) " +
               "VALUES(@ProductID, @ProductName, @ProductPrice, @ProductQuantity, @ProductImage)";
        SqlCommand com = new SqlCommand(productQuery, conn);

        // com.Parameters.AddWithValue("@ID", newGUID.ToString());
        com.Parameters.AddWithValue("@ProductID", TextBoxProductID.Text);
        com.Parameters.AddWithValue("@ProductName", TextBoxProductName.Text);

        com.Parameters.AddWithValue("@ProductPrice", TextBoxProductPrice.Text);
        com.Parameters.AddWithValue("@ProductQuantity", TextBoxProductQuantity.Text);
        com.Parameters.AddWithValue("@ProductImage", b.ToString());

        com.ExecuteNonQuery();
    }
}