﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class User_ProductDescription : System.Web.UI.Page
{

    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ConnectionString);
    int id;
    string productname, productdesc,productprice, productquantity,productimages;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Request.QueryString["id"] == null)
        {
            Response.Redirect("DisplayItem.aspx");
        }
        else
        {
            id = Convert.ToInt32(Request.QueryString["id"].ToString());
            conn.Open();

            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = "Select * from product where ProductID ='+id'";
            id = Convert.ToInt32(Request.QueryString["id"].ToString());
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);

            d1.DataSource = dt;
            d1.DataBind();



            conn.Close();
        }
        

    }

    protected void b1_Click(object sender, EventArgs e)
    {
        conn.Open();
        SqlCommand cmd = conn.CreateCommand();
        cmd.CommandType = System.Data.CommandType.Text;
        cmd.CommandText = "Select * from product";
        cmd.ExecuteNonQuery();

        DataTable dt = new DataTable();

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);

        foreach(DataRow dr in dt.Rows)
        {
            productname = dr["ProductName"].ToString();
            productdesc = dr["ProductDesc"].ToString();
            productprice = dr["ProductPrice"].ToString();
            productquantity = dr["ProductQuantity"].ToString();
            productimages = dr["ProductImage"].ToString();

        }

        d1.DataSource = dt;
        d1.DataBind();



        conn.Close();

        if (Request.Cookies["aa"] == null)
        {
            Response.Cookies["aa"].Value = productname.ToString() + "," + productdesc.ToString() +
                "," + productprice.ToString() + "," + productquantity.ToString() + "," + 
                productimages.ToString();
            Response.Cookies["aa"].Expires = DateTime.Now.AddDays(1);

        }
        else
        {
            Response.Cookies["aa"].Value = Request.Cookies["as"].Value+productname.ToString() + "," + productdesc.ToString() +
                "," + productprice.ToString() + "," + productquantity.ToString() + "," +
                productimages.ToString();
            Response.Cookies["aa"].Expires = DateTime.Now.AddDays(1);
        }
    }
}