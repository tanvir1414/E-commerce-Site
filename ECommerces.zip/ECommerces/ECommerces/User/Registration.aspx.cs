﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {

            //    Guid newGUID = Guid.NewGuid();
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ConnectionString);
            conn.Open();

            string insertQuery = "INSERT INTO UserRegistration (UserID,UserName,Email,Phone,Pass,Address,Country) " +
                "values(@UserID,@Username,@email,@phone,@password,@address,@country)";
            SqlCommand com = new SqlCommand(insertQuery, conn);

            // com.Parameters.AddWithValue("@ID", newGUID.ToString());
            com.Parameters.AddWithValue("@UserID", TextBoxUserID.Text);
            com.Parameters.AddWithValue("@UserName", TextBoxName.Text);

            com.Parameters.AddWithValue("@email", TextBoxEmail.Text);
            com.Parameters.AddWithValue("@phone", TextBoxPhone.Text);
            com.Parameters.AddWithValue("@password", TextBoxPass.Text);
            com.Parameters.AddWithValue("@Address", TextBoxAddress.Text);
            com.Parameters.AddWithValue("@country", DropDownListCountry.SelectedItem.ToString());


            com.ExecuteNonQuery();





            Response.Redirect("UserInformation.aspx");
            //   Response.Write("Registration Successful");
            conn.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error : " + ex.ToString());
        }
    }
}
