﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {

/*
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ConnectionString);
        conn.Open();
        string checkuser = "Select count(1) from UserRegistration where UserID =@userID AND Pass =@pass";
        SqlCommand com = new SqlCommand(checkuser, conn);

        com.Parameters.AddWithValue("@userID", TextBoxUserID.Text.Trim());
        com.Parameters.AddWithValue("@pass", TextBoxPass.Text.Trim());

        int count = Convert.ToInt32(com.ExecuteScalar());

        if (count == 1)
        {
            Session["userID"] = TextBoxUserID.Text.Trim();
            Response.Redirect("UserInformation.aspx");
        }

*/
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ConnectionString);
         conn.Open();
         string checkuser = "Select count(1) from [UserRegistration] where UserID ='" + TextBoxUserID.Text + "'";
         //string checkuser = "select count(*) from [Table] where UserName = ' "TextBoxUser.Text"'";


         SqlCommand com = new SqlCommand(checkuser, conn);

         
             int temp = Convert.ToInt32(com.ExecuteScalar().ToString());

             if (temp == 1)
             {
                // conn.Open();
                 string checkPasswordQuery = "Select Pass from UserRegistration where UserID ='" + TextBoxUserID.Text + "'";
                 SqlCommand passcom = new SqlCommand(checkPasswordQuery, conn);

                 string password = passcom.ExecuteScalar().ToString();
                 if (password == TextBoxPass.Text)
                 {
                     Session["New"] = TextBoxUserID.Text;
                     Response.Write("password is correct");
                     Response.Redirect("Users.aspx");

                 }
                 else
                 {
                     Response.Write("Password is incorrect");
                 }
             }
             else
             {
                 Response.Write("UserName is incorrect");
             }
    }
         




    protected void TextBoxPass_TextChanged(object sender, EventArgs e)
    {

    }
}
