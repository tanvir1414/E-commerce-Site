﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class User_DisplayItem : System.Web.UI.Page
{

    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        conn.Open();

        SqlCommand cmd = conn.CreateCommand();
        cmd.CommandType = System.Data.CommandType.Text;
        cmd.CommandText = "Select * from product";
        cmd.ExecuteNonQuery();

        DataTable dt = new DataTable();

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);

        d1.DataSource = dt;
        d1.DataBind();



        conn.Close();

    }
}